<h3 align="center">
📚 Decodificador de Texto - Alura Challenges Oracle ONE
</h3>

##  🔖 Informações

 <p>Challenge ONE Sprint 01: Construa um decodificador de texto com Javascript

<h3 align="center">
    <img src="image-readme/capa1.png" alt="JAVA-SCRIPT" width="250" height="150">
    <img src="image-readme/capa2.png" alt="JAVA-SCRIPT" width="250" height="150">
    <img src="image-readme/capa3.png" alt="JAVA-SCRIPT" width="250" height="150">
</h3>

##  🚀 Tecnologias Usadas

<br/>
<p align="left">
<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg" alt="JAVA-SCRIPT" width="200" height="200" />
<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original.svg" alt="HTML" width="200" height="200" />
<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-original.svg" alt="CSS" width="200" height="200" />
</p>

### Modelo Figma
```bash
https://www.figma.com/file/tvFEYhVfZTjdJ5P24RGV21/Alura-Challenge---Desafio-1---L%C3%B3gica?node-id=0%3A1&t=1InX4dUf4CVZrvsM-0
```
### TRELLO - Decodificador de Texto - Alura
```bash
https://www.figma.com/file/tvFEYhVfZTjdJ5P24RGV21/Alura-Challenge---Desafio-1---L%C3%B3gica?node-id=0%3A1&t=1InX4dUf4CVZrvsM-0
```
<br>

#  🔗 Challenge ONE Sprint 01:
Construa um decodificador de texto com Javascript

```bash
https://www.alura.com.br/challenges/challenge-one-logica/sprint01-construa-decodificador-texto-com-javascript
```
##  🐠 Aluno
<table align="center">
<tr>
<td align="center">
<a href="https://github.com/Rilque">
<br />
<sub><b>Rilque-Rapozo</b></sub>
</a>
</td>
</tr>
</table>
<h4 align="center">
By<a href="https://github.com/Rilque" target="_blank"> Rilque-Rapozo </a>🐠
</h4>